<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>Universidad de Concepción del Uruguay</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

   <?php include_http_metas() ?>
    <?php include_metas() ?>
    <?php include_title() ?>
    <link rel="shortcut icon" href="/favicon.ico" />
    
	<?php use_stylesheet('jdMenu.css') ?>        

    <?php use_stylesheet('jquery-ui-1.8.20.custom.css') ?>
    <?php use_stylesheet('av_autogestion.css') ?>
    <?php use_stylesheet('ui.jqgrid.css') ?>   

    
    <?php use_javascript('jquery.jdMenu.js') ?>  
    <?php use_javascript('analytics.js') ?>  		
    <?php use_javascript('hoverIntent.js') ?>
    <?php use_javascript('superfish.js') ?>        
	<?php use_javascript('jquery.validator.js') ?>      
    <?php use_javascript('grid.locale-es.js') ?>
    <?php use_javascript('jquery.jqGrid.min.js') ?>
    
    <?php include_stylesheets() ?>
    <?php include_javascripts() ?>
<script type="text/javascript">
	// initialise plugins
	jQuery(function(){
		$('ul.sf-menu sf-navbar').superfish({
			pathClass:  'current' 
		});
		
		$('ul.sf-menu sf-vertical').superfish({ 
    		animation: {height:'show'},   // slide-down effect without fade-in
			delay:     1200               // 1.2 second delay on mouseout 
		}); 
	});
</script> 
</head>
<body>
<table align="center" border="0" width="70%" ">
  <tbody>
    <tr>
      <td>
      <table class="encabezadologin"  >
          <tr>
            <td class="titulo">
            <?php if (!$sf_user->isAuthenticated()) { ?>
            <img alt="" src="<?php echo $sf_request->getRelativeUrlRoot();?>/images/cabeceraucu_2015.jpg">
            <?php }else{ ?>
            <img alt="" src="<?php echo $sf_request->getRelativeUrlRoot();?>/images/cabeceraucu_2015.jpg">
            <?php } ?>                       
            </td>
          </tr>
          <tr height="21px">
			<?php if ($sf_user->isAuthenticated()) { ?>
            <td align="center" colspan="2" >
		      <table class="cuerpo">
		          <tr>
		            <td class="titulo_sistema" >Sistema de Alumnos On-line</td>
					<td class="subtitnegro" >					
						<ul class="jd_menu jd_menu_slate" >
							<li><a class="accessible"><?php echo $sf_user->getGuardUser()->getFirstName()." ".$sf_user->getGuardUser()->getLastName(); ?></a>
						<ul>
							<li><a href="<?php echo url_for('personas/modificardatospersonales') ?>">Datos personales</a></li>
							<li><a href="<?php echo url_for('usuario/cambiarpassword') ?>">Cambiar Contraseña</a></li>
							<li><a href="<?php echo url_for('@sf_guard_signout') ?>">Salir</a></li>
						</ul>	
					</td>
		          </tr>
		      </table>	  
  
			</td>            
			<?php } else { ?>
			<td colspan="2">&nbsp</td>	
            <?php } ?>              
            
          </tr>          
      </table>
      <table border="0" cellpadding="0" bgcolor="#ffffff" cellspacing="0" width="100%"">
        <tbody>
          <tr>
            <td width="190" valign="top" >      
	            <?php 
				$mensaje_usuario='';
				if ($sf_user->isAuthenticated()){   ?>    		 
	       		 <div class="menu-container">
	       		 	<h1 align="center">Gestión</h1>
						<ul class="sf-menu sf-vertical estilo-menu">							
							    <!-- **** MENU ALUMNO **** -->
							    <?php if($sf_user->hasCredential('alumno')) { 
									//Control de tener dni en sistema de administracion
									//conexion webservice administrativo
									$soapclient = new nusoap_client("http://192.168.2.195/administracion/webservices/personacuenta.php?wsdl");
									$soapclient->setCredentials("root", "sistemas2009");
											
									//llamamos la función implementada en el server.php de la siguiente manera
									$resultado = $soapclient->call('obtenerpersona',array('value' => $sf_user->getProfile()->getNrodoc()));
								    sfContext::getInstance()->getUser()->setAttribute('nrodoc',$sf_user->getProfile()->getNrodoc());
								    sfContext::getInstance()->getUser()->setAttribute('idsede',$sf_user->getProfile()->getIdsede());
									$this->persona = unserialize(base64_decode($resultado));
								?>
							    <li><a href="<?php echo url_for('ingreso/index') ?>">Inicio</a></li>
								<?php // si la persona no posee dni en sistema administrativo se oculta opciones de menu y se informa al sector administrativo 
							
								if ($this->persona!=NULL) {	?>
									<li><a href="<?php echo url_for('ciclo/getplanesactivacion') ?>">Inscripción a Ciclo Lectivo</a></li>	
									<li><a href="<?php echo url_for('inscripciones/inscribirmaterias') ?>">Inscripción para Cursar</a></li>	

<li><a href="<?php echo url_for('inscripciones/inscribirmateriasrendir') ?>">Inscripción a Mesas</a></li>	

								<?php }  else { // envio de mail con datos del alumno
									$mensaje_usuario= "
	                                	<blockquote>
											<p>
											<b>Tramites Pendientes:</b> Su cuenta esta siendo habilitada, Las opciones adicionales se activaran a la brevedad.
											</p>
										</blockquote>";
								} ?>				
								<?php // VER ESTOOOOOO ?>



							    <li><a href="<?php echo url_for('analitico/getanalitico') ?>">Analítico</a></li>
 <li><a href="<?php echo url_for('alumat') ?>">Histórico de Materias</a></li>
							    <li><a href="<?php echo url_for('calendarios/index') ?>">Calendario</a></li>
								<li><a href="<?php echo url_for('solicitudes/index') ?>">Mensajería Interna</a></li>             
	<li><a href="<?php echo url_for('informes/planesestudios') ?>">Plan de Estudio</a></li>  
	<li><a href="<?php echo url_for('informes/correlatividades') ?>">Régimen de Correlatividades</a></li>     
	        				</ul>       		 
	            </div><br><br>
	            <?php }
			?>
		        <?php if($sf_user->hasCredential('alumno')) {  ?>
			        <p>
			        <div class="sidebaritem">
			          <h1><a style='color:#F93333; font-size:18px; align: center '>Links de Interés</a></h1><br>
			          <!-- **** INSERT NEWS ITEMS HERE **** -->

			          <h2><a href="http://www.ucu.edu.ar/index.php?option=com_content&view=article&id=585:como-obtener-una-beca-en-la-ucu&catid=52:alumnado&Itemid=30" target="_blank">BECAS</a></h2>
			          <p>¿Cómo gestionar una beca?</p>
			          <br>
			          <h2><a onclick="window.open('http://www.ucu.edu.ar/images/stories/recorridoucu/ciudad.swf','mywindow','scrollbars=no,menubar=no,width=729,height=340,toolbar=no,location=no,status=no')" href="http://www.ucu.edu.ar/">RECORRIDO VIRTUAL</a></h2>
			          <p>Conoce nuestra Sede Central</p>
			          <br>
			          <h2><a href="http://campus.ucu.edu.ar" target="_blank">UCU - Campus Virtual</a></h2>
			           <p>Cursos y Cátedras On-line</p></p>

			          <h1><a style='color:#F93333; font-size:18px; align: center '>Institucional</a></h1><br>
			       
			          <h2><a href="<?php echo url_for('reglamentos/index') ?>" target="_blank">Reglamentos</a></h2>
			           <p>Reglamentos Generales</p>
			        </div>



			        </p>
		        <?php  } ?>                       
            <?php } ?>              
            </td>
            <td valign="top" style="border-left:1px solid #7b76b6;">
            <div id="column2">
				<?php 
					echo $mensaje_usuario;
					echo $sf_content;
				?>
			</div>
            </td>
          </tr>
        </tbody>
      </table>
      </td>
    </tr>
  </tbody>
  <tfoot>
  	<tr>
      <td>
		<?php if (!$sf_user->isAuthenticated()) { ?>
			<table class="pielogin">
				<tr>
					<td>
					<img alt="" src="<?php echo $sf_request->getRelativeUrlRoot();?>/images/pieUCU.jpg">
					</td>
				</tr> 
			</table>
      	<?php }else{ ?>
		  <table  class="pieloginon">
			<tr>
				<td width="12%"></td>
				<td width="26%"><div id="titlefooter"><img alt="Links de Interés" src="<?php echo $sf_request->getRelativeUrlRoot();?>/images/icon-info.png">Links de Interés</div></td>
				<td width="2%"></td>
				<td width="2%"></td>
				<td width="27%"><div id="titlefooter"><img alt="Seguinos en" src="<?php echo $sf_request->getRelativeUrlRoot();?>/images/icon-seguinos.png">Seguinos en</div></td>
				<td width="2%"></td>
				<td width="2%"></td>
				<td width="26%"><div id="titlefooter"><img alt="Contacto" src="<?php echo $sf_request->getRelativeUrlRoot();?>/images/icon-contacto.png">Contacto</div></td>
			</tr>
			<tr>
				<td></td>
				<td class="punteado" valign="top"><div id="txtfooter">
				<ul>
				<li><a href="http://www.ucu.edu.ar" target="_blank"><img alt="UCU" src="<?php echo $sf_request->getRelativeUrlRoot();?>/images/icon-web.png">UCU Web</a><br>
				<a href="http://biblioteca.ucu.edu.ar" target="_blank"><img alt="Biblioteca Central" src="<?php echo $sf_request->getRelativeUrlRoot();?>/images/icon-biblio.png">Biblioteca Central</a><br>
				</li></ul></div>
				</td>
				<td></td>
				<td></td>
				<td class="punteado" valign="top" ><div id="txtfooter">
				<ul>
				<li>
				<a href="http://www.facebook.com/ucu.oficial" target="_blank"><img alt="Facebook" src="<?php echo $sf_request->getRelativeUrlRoot();?>/images/icon-facebook.png"> UCU </a><br>
				<a href="http://twitter.com/#!/@UCUNoticias" target="_blank"><font color="#ffffff"><img alt="Twitter" src="<?php echo $sf_request->getRelativeUrlRoot();?>/images/icon-twitter.png"> @UCUNoticias</a><br>
				</font>
				</li></ul></div></td>
				<td></td>
				<td></td>
				<td valign="top"><div id="txtfooter">
					8 de junio 522 - CP E3260ANJ<br>
					Concecpión del Uruguay - Entre Ríos<br>
					Tel./Fax: 00 54 3442-425606/427721
				</div></td>
			</tr>	  
		  </table>
		<?php } ?>      
	  </td>
      </tr>
  </tfoot>
</table>
<p style="text-align: center;"><small>copyright © 2012 U.C.U. | sistemas@ucu.edu.ar</small><br>
</p>
</body></html>
